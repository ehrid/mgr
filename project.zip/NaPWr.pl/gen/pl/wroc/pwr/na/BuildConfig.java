/** Automatically generated file. DO NOT MODIFY */
package pl.wroc.pwr.na;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}