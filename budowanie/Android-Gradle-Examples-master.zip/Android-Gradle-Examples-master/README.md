Android-Gradle-Examples
=======================

For the accompanying presentation see https://docs.google.com/presentation/d/1s6D1GwjKeoG9cEsTEXlWPGyo6kbLFNB6EXxsUtDB9IA/edit?usp=sharing